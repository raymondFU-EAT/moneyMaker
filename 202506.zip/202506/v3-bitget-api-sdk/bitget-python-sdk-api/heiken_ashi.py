def calculate_heiken_ashi(candles):
    ha_candles = []

    for i, c in enumerate(candles):
        open_p = float(c['open'])
        high_p = float(c['high'])
        low_p = float(c['low'])
        close_p = float(c['close'])

        ha_close = (open_p + high_p + low_p + close_p) / 4

        if i == 0:
            ha_open = open_p
        else:
            prev_ha = ha_candles[-1]
            ha_open = (prev_ha['ha_open'] + prev_ha['ha_close']) / 2

        ha_high = max(high_p, ha_open, ha_close)
        ha_low = min(low_p, ha_open, ha_close)

        ha_candle = {
            'timestamp': c['timestamp'],
            'datetime': c['datetime'],
            'ha_open': ha_open,
            'ha_high': ha_high,
            'ha_low': ha_low,
            'ha_close': ha_close,
            'volume': float(c.get('volume', 0)),
            'turnover': float(c.get('turnover', 0))
        }
        ha_candles.append(ha_candle)

    return ha_candles

# 測試用main區塊(可選)
if __name__ == "__main__":
    # 這邊示範調用時需要先有candles資料
    from read_candles import get_sample_raw_data, parse_candle_data
    raw = get_sample_raw_data()
    candles = parse_candle_data(raw)
    ha = calculate_heiken_ashi(candles)
    for h in ha:
        print(h)
