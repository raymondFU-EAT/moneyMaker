from read_candles import getHisCandleData
from heiken_ashi import calculate_heiken_ashi
from bitget.exceptions import BitgetAPIException

def main():
    try:
        symbol = "BTCUSDT_UMCBL"
        granularity = "60"
        startTime = "2025-06-01 00:00:00"
        endTime = "2025-06-01 01:00:00"

        data = getHisCandleData(symbol, granularity, startTime, endTime)
        ha_data = calculate_heiken_ashi(data)

        print("Heiken Ashi 資料：")
        for candle in ha_data:
            print(candle)

    except BitgetAPIException as e:
        print("Bitget API 錯誤:", e)
    except Exception as e:
        print("其他錯誤:", e)

if __name__ == '__main__':
    main()
