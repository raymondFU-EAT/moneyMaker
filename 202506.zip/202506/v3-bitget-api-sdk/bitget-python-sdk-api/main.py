from read_candles import getHisCandleData
from bitget.exceptions import BitgetAPIException

if __name__ == '__main__':
    try:
        symbol = "BTCUSDT_UMCBL"
        granularity = "60"  # 60秒K線
        startTime = "2025-06-01 00:00:00"
        endTime = "2025-06-01 01:00:00"
        data = getHisCandleData(symbol, granularity, startTime, endTime)
        for d in data:
            print(d)
    except BitgetAPIException as e:
        print("Bitget API錯誤:", e)
    except Exception as e:
        print("其他錯誤:", e)
