import bitget.v1.mix.order_api as maxOrderApi
import bitget.bitget_api as baseApi
import datetime
from bitget.exceptions import BitgetAPIException
import config

def datetime_to_millis(year, month, day, hour, minute, second):
    dt = datetime.datetime(year, month, day, hour, minute, second)
    timestamp_s = dt.timestamp()  # 秒級時間戳
    timestamp_ms = int(timestamp_s * 1000)  # 毫秒時間戳
    return timestamp_ms

def millis_to_str(timestamp_ms):
    timestamp_s = timestamp_ms / 1000
    dt = datetime.datetime.fromtimestamp(timestamp_s)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def str_to_millis(date_str):
    dt = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
    timestamp_s = dt.timestamp()
    timestamp_ms = int(timestamp_s * 1000)
    return timestamp_ms

def parse_candle_data(raw_data):
    # keys = ["timestamp", "open", "high", "low", "close", "volume", "turnover"]
    result = []

    for entry in raw_data:
        item = {}
        item["timestamp"] = int(entry[0])
        item["datetime"] = millis_to_str(item["timestamp"])
        item["open"] = float(entry[1])
        item["high"] = float(entry[2])
        item["low"] = float(entry[3])
        item["close"] = float(entry[4])
        item["volume"] = float(entry[5])
        item["turnover"] = float(entry[6])
        result.append(item)

    print(result)
    return result

def key():
    return baseApi.BitgetApi(config.API_KEY, config.SECRET_KEY, config.PASSPHRASE)

def getHisCandleData(symbol, granularity, startTime, endTime):
    params = {
        "symbol": symbol,
        "granularity": granularity,
        "startTime": str_to_millis(startTime),
        "endTime": str_to_millis(endTime)
    }
    api = key()
    response = api.get(request_path="/api/mix/v1/market/history-candles", params=params)
    return parse_candle_data(response)

