import matplotlib.pyplot as plt
from read_candles import getHisCandleData
from heiken_ashi import calculate_heiken_ashi
from bitget.exceptions import BitgetAPIException

def plot_heiken_ashi(data):
    times = [c['datetime'] for c in data]
    ha_closes = [c['ha_close'] for c in data]

    plt.figure(figsize=(12, 6))
    plt.plot(times, ha_closes, marker='o', linestyle='-', color='green', label='Heiken Ashi Close')
    plt.xlabel("時間")
    plt.ylabel("價格")
    plt.title("Heiken Ashi 線圖")
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

def main():
    try:
        symbol = "BTCUSDT_UMCBL"
        granularity = "1H"
        startTime = "2025-06-30 05:00:00"
        endTime = "2025-06-30 17:00:00"

        data = getHisCandleData(symbol, granularity, startTime, endTime)
        ha_data = calculate_heiken_ashi(data)

        print("繪圖中...")
        plot_heiken_ashi(ha_data)

    except BitgetAPIException as e:
        print("Bitget API 錯誤:", e)
    except Exception as e:
        print("其他錯誤:", e)

if __name__ == '__main__':
    main()
