# Bitget Open API V3 SDK

### Supported language: Java,  Python, Node, Go,Php
---

|list|language|comment|
|---|---|---|
|bitget-java-sdk-api|Java|-|
|bitget-python-sdk-api|Python|-|
|bitget-node-sdk-api|Node|-|
|bitget-golang-sdk-api|Go|-|
|bitget-php-sdk-api|Php|-|

Please join [Telegram](https://t.me/bitgetOpenapi)
