import requests

def get_public_ip():
    try:
        response = requests.get("https://api.ipify.org?format=json")
        response.raise_for_status()
        ip = response.json()["ip"]
        print(f"你的公網 IP 是：{ip}")
    except requests.RequestException as e:
        print(f"取得 IP 失敗：{e}")

get_public_ip()
